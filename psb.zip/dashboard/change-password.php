<?php

public function change_password()
	{
		$data['title']			= 'Ubah Password';
		$data['user_login_data'] = $this->user_login_data;
		############# ============= ##############
		change_password_validation();
		if ($this->form_validation->run()==FALSE) {
			$this->load->view('v_user/user_change_password',$data);
		} else {
			$id_user 		= $this->input->post('id_user');
			$old_password 	= $this->input->post('old_password');// password hash 
			$your_password 	= $this->input->post('your_password'); // password sekarang
			$new_password 	= $this->input->post('new_password'); // password baru
			if (!password_verify($new_password, $old_password)) {
				if (password_verify($your_password, $old_password)) {
					$this->M_User->update_user($id_user,["password" => password_hash($new_password, PASSWORD_DEFAULT)]);
					$this->session->set_flashdata('success', 'Password anda berhasil diperbarui');
					redirect('user/change-password');
				}else{
					$this->session->set_flashdata('danger', 'Password yang anda masukan salah');
					redirect('user/change-password');
				}
			}else{
				$this->session->set_flashdata('warning', 'Password tidak boleh sama dengan password sekarang');
				redirect('user/change-password');
			}
		}
	}
    ?>
                <div class="form-group">
                  <input type="hidden" class="form-control" readonly="" value="<?= $user_login_data['id_user'] ?>" name="id_user">
                </div>
                <div class="form-group">
                  <input type="hidden" class="form-control" readonly="" value="<?= $user_login_data['email'] ?>" name="email">
                </div>
                <div class="form-group">
                  <input required="" type="hidden" class="form-control" value="<?= $user_login_data['password'] ?>" name="old_password">
                </div>
                <div class="form-group">
                  <input required="" type="" class="form-control" placeholder="Password anda" value="" name="your_password">
                </div>
                <div class="form-group">
                  <input required="" type="" class="form-control" placeholder="Password baru" value="" name="new_password">
                  <?= form_error('new_password','<small class="text-danger">','</small>') ?>
                </div>
                <?= get_csrf(); ?>
                <button type="submit" class="btn btn-primary">KONFIRMASI</button>
              </form>
            </div>

          </div>

        </div>
        <!-- /.card-body -->
        <div class="card-footer">
          <?= $title; ?>
        </div>
        <!-- /.card-footer-->
      </div>
      <!-- /.card -->

      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->